<?php
function globalFunction()
{
}
